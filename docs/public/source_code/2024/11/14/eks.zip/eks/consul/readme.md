After installed consul using consul-value.yaml and helm, do the following

export CONSUL_HTTP_TOKEN=$(kubectl get --namespace consul secrets/consul-bootstrap-acl-token --template={{.data.token}} | base64 -d)

export CONSUL_HTTP_ADDR=https://$(kubectl get services/consul-ui --namespace consul -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

export CONSUL_HTTP_SSL_VERIFY=false


Then you can retrieve the consul url using:
echo $CONSUL_HTTP_ADDR

and token using
echo $CONSUL_HTTP_TOKEN


use curl -k to ignore the ssl cert warning

# traffic splitter
you need a service resolver and service splitter to split the traffic.
Also, remember to add annotation consul.hashicorp.com/service-meta-version to each pods you want to split traffic to.

```yaml
# e.g. service resolver
apiVersion: consul.hashicorp.com/v1alpha1
kind: ServiceResolver
metadata:
  name: echo-1
  namespace: default
spec:
  # Splits traffic between tcp-echo-v1 and tcp-echo-v2 with weights
  subsets:
    v1:
      filter: "Service.Meta.version == 1" # match "consul.hashicorp.com/service-meta-version": "1"
    v2:
      filter: "Service.Meta.version == 2"
  defaultSubset: v1
```

```yaml
# service splitter
apiVersion: consul.hashicorp.com/v1alpha1         # string | required
kind: ServiceSplitter                             # string | required
metadata:                                         # object | required
  name: echo-1                                  # string | required
  namespace: default
spec:                                             # object | required
  splits:
    - serviceSubset: v1
      weight: 95
    - serviceSubset: v2
      weight: 5
```