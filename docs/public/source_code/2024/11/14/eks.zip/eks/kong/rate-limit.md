# Kong Rate Limit
- kong rate limit function is applied as a plugin
- minute: 5 means number of request per minute
```yaml
apiVersion: configuration.konghq.com/v1
kind: KongPlugin
metadata:
  name: rate-limit-5-min
  annotations:
    kubernetes.io/ingress.class: kong
config:
  minute: 5
  policy: local
plugin: rate-limiting
```

## Associate the plugin with a service or route
```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: echo
  annotations:
    konghq.com/strip-path: 'true' # Strip the path (/echo) before forwarding the request to the service
    konghq.com/plugins: rate-limit-5-min # allow 5 requests per minute
```