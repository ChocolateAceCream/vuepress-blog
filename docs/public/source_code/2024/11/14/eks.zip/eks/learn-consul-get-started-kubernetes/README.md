# Getting Started with Consul on Kubernetes

Install Consul on Kubernetes and quickly explore service mesh features such as service-to-service permissions with intentions, ingress with API Gateway, and enhanced observability.

## Tutorial Collection URL

[https://developer.hashicorp.com/consul/tutorials/get-started-kubernetes](https://developer.hashicorp.com/consul/tutorials/get-started-kubernetes)